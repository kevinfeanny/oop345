#pragma once
#ifndef PROCESS_
#define PROCESS_


void process(const char *str);


#endif // !PROCESS_
