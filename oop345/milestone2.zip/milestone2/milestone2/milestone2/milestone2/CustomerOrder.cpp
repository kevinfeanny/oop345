#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include "CustomerOrder.h"
#include "CustomerItem.h"
#include "Item.h"
#include "Utilities.h"

using namespace std;

size_t CustomerOrder::field_width;

CustomerOrder::CustomerOrder(const std::string& custOrder) {
	/*
	custOrder contains the information for a single customer order.
	Task 1 : initializes the number of customer items to 0 and the pointer to customerArray to a safe address.
	Task 2 : Using a Utilities object extract the tokens from custOrder
	Task 3 : Report an exception if any tokens are returned empty
	Task 4 : The constructor allocates dynamic memory for *order
	Task 5 : Sets field_width to the Utilities objects field_width only if the Utilities field_width is greater.
	* custOrder layout*
	customer name field | product name field | Item name field
	*/
	nOrders = 0; order = nullptr;  //  Task 1.

	Utilities zoolander;
	std::vector<std::string> token;
	size_t pos = 0; bool isMore = true;
	//  Task 2 Begins

	    name = zoolander.nextToken(custOrder, pos, isMore);

		if (isMore) { product = zoolander.nextToken(custOrder, pos, isMore); }
		
		while (isMore) {
			std::string t = zoolander.nextToken(custOrder, pos, isMore);
			if (t.size() > 0)
				token.push_back(t);
		}

		order = new CustomerItem[token.size()];  //  Task 4.
		
		for (unsigned int i = 0; i < token.size(); i++) {
			order[i] = CustomerItem(token[i]);
			
		}

		if (field_width < zoolander.getFieldWidth()) { //  Task 5.
			field_width = zoolander.getFieldWidth();
		}
		nOrders = token.size();
	
} 

CustomerOrder::CustomerOrder(const CustomerOrder& rhs)
{
	
#ifndef _APPLE_
	throw std::string("the copy constructor should never be called");
#else
	name = rhs.name;
	product = rhs.product;
	nOrders = rhs.nOrders;

	if (rhs.order)
	{
		order = new CustomerItem[nOrders];
		for (int i = 0; i < nOrders; i++)
			order[i] = rhs.order[i];
	}
	else
	{
		order = nullptr;
	}
#endif

}

CustomerOrder::CustomerOrder(CustomerOrder&& rhs) NOEXCEPT
{
	order = nullptr;
	*this = std::move(rhs);
}

CustomerOrder&& CustomerOrder::operator=(CustomerOrder&& rhs) NOEXCEPT
{
	if (this != &rhs)
	{
		if (order)
			delete[] order;

		name = rhs.name;
		product = rhs.product;
		nOrders = rhs.nOrders;
		order = rhs.order;
		
		rhs.name.clear();
		rhs.product.clear();
		rhs.nOrders = 0;
		rhs.order = nullptr;
	}

	return std::move(*this);
}
CustomerOrder::~CustomerOrder() {
	//deletes dynamic memory in use by the current object.
	delete[] order;
}
unsigned int CustomerOrder::noOrders() const { return nOrders; }
const string& CustomerOrder::operator[](unsigned int i) const {
	try {
		string Kname;
		Kname = order[i].getName();

	}
	catch (...) {

	}
	return name;


}
void CustomerOrder::fill(Item& item) {
	for (unsigned int i = 0; i < nOrders; i++) {
		if (order[i].asksFor(item)) {
			order[i].fill(item.getCode());
			item++;
		}
	}
}
void CustomerOrder::remove(Item& item) {

	for (unsigned int i = 0; i < nOrders; i++) {
		if (order[i].getName() == item.getName()) {
			nOrders--;
		}
	}



}
bool CustomerOrder::empty() const { return (order == nullptr) ? true : false; }
void CustomerOrder::display(ostream& os) const {

	os << std::setw(field_width) << std::setfill(' ') << std::left << name << " :  " << product << std::endl;
	for (unsigned int i = 0; i < nOrders; i++) {
		order[i].display(os);
	}



}
