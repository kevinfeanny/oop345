
#include <iostream>
#include <string>
#include <algorithm> 
#include <functional> 
#include <cctype>
#include <locale>
#include "Utilities.h"


	char Utilities::delimiter;
	std::ofstream Utilities::logFile;

	Utilities::Utilities() {
		//initializes field_width to 1.
		field_width = 1;
	}

	size_t Utilities::getFieldWidth() const {
		//returs the field_width of the current object.
		return this->field_width;
	}
	const std::string Utilities::nextToken(const std::string& str, size_t& next_pos, bool& more) {
		std::string token = "";

		// read token until delimiter
		while (str.size() != next_pos && str[next_pos] != delimiter)
		{
			token += str[next_pos];
			next_pos++;
		}

		if (str.size() == next_pos)
		{
			more = false;
		}
		else
		{
			more = true;
			next_pos++;
		}

		// trim white space, tab, and carriage return
		size_t p = token.find_first_not_of(" \t\r\n");
		token.erase(0, p);

		p = token.find_last_not_of(" \t\r\n");
		if (std::string::npos != p)
			token.erase(p + 1);

		if (field_width < token.size())
			field_width = token.size();

		return token;
	}
	void Utilities::setDelimiter(const char pDelim) {
		//Resets delim for this class to pDelim.
		Utilities::delimiter = pDelim;
	}
	void Utilities::setLogFile(const char* logfile) {
		//Opens logfile for writing and truncation. 
		logFile.close();
		logFile.open(logfile);
	}
	std::ofstream& Utilities::getLogFile() {
		//returns a reference to the logfile.
		return logFile;
	}




