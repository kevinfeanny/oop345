#include <iomanip>
#include <iostream>
#include "CustomerItem.h"
#include "Item.h"

using namespace std;

CustomerItem::CustomerItem(const string& Pname) {

	name = "";
	if (!Pname.empty()) {
		name = Pname;
		}
	filled = false;
	code = 0;
}
bool CustomerItem::asksFor(const Item& item) const { return name == item.getName() ? true : false; }
bool CustomerItem::isFilled() const { return filled; }
void CustomerItem::fill(const unsigned int fill) { code = fill; filled = true; }
void CustomerItem::clear() { code = 0; filled = false; }
const string& CustomerItem::getName() const { return name; }
void CustomerItem::display(ostream& os) const {

	if (isFilled()) { os << " + "; }
	else { os << " - "; }

	os << "[" << std::setw(CODE_WIDTH) << std::setfill('0') << std::right << code << "]  " << name << std::endl;



}